#!/bin/bash
set -x
set -v
if [ ! -d /lib/modules/3.14.56 ] 
then
	echo "directory /lib/modules/3.14.56 doesn't exits!"
	exit
fi

cp -f ./modules.* /lib/modules/3.14.56/
mkdir -p /lib/modules/3.14.56/kernel/drivers/media/radio
cp dsbr100.ko /lib/modules/3.14.56/kernel/drivers/media/radio/
cp radio3 /usr/bin/radio3
